# SPDX-FileCopyrightText: 2025-present NII Gakunin Cloud <cld-office-support@nii.ac.jp>
#
# SPDX-License-Identifier: Apache-2.0
"""Types for vcp-schedule-utils."""

import sys
from datetime import datetime as dt

if sys.version_info >= (3, 11):
    from typing import Literal, NotRequired, TypeAlias, TypedDict
else:
    from typing import Literal, TypeAlias, TypedDict

    from typing_extensions import NotRequired


class SwarmNodeStatus(TypedDict):
    """Swarm Node status."""

    active: int
    pause: int
    drain: int


class OcsNodeStatus(TypedDict):
    """OCS Node status."""

    up: int
    drain: int
    power_down: int
    deleted: NotRequired[int]


class DailySchedule(TypedDict):
    """Daily schedule."""

    hour: int
    minute: int


class WeeklySchedule(DailySchedule):
    """Weekly schedule."""

    day_of_week: int


class MonthlySchedule(DailySchedule):
    """Monthly schedule."""

    day: int


class YearlySchedule(MonthlySchedule):
    """Yearly schedule."""

    month: int


class SpecificDateSchedule(YearlySchedule):
    """Specific date schedule."""

    year: int


Schedule: TypeAlias = (
    DailySchedule | WeeklySchedule | MonthlySchedule | YearlySchedule | SpecificDateSchedule
)
SwarmSchedule: TypeAlias = DailySchedule | WeeklySchedule | MonthlySchedule


class SwarmNodeStatusSchedule(SwarmNodeStatus):
    """Swarm Node status schedule."""

    schedule: SwarmSchedule


class NodeDefaultParams(TypedDict):
    """Node default parameters."""

    node_count: int
    max_node_count: NotRequired[int]
    down_type: str
    drain_time: NotRequired[int]


class DailyPeriod(TypedDict):
    """Daily period."""

    begin: DailySchedule
    end: DailySchedule


class WeeklyPeriod(TypedDict):
    """Weekly period."""

    begin: WeeklySchedule
    end: WeeklySchedule


class MonthlyPeriod(TypedDict):
    """Monthly period."""

    begin: MonthlySchedule
    end: MonthlySchedule


class YearlyPeriod(TypedDict):
    """Yearly period."""

    begin: YearlySchedule
    end: YearlySchedule


class SpecificDatePeriod(TypedDict):
    """Specific date period."""

    begin: SpecificDateSchedule
    end: SpecificDateSchedule


Period: TypeAlias = DailyPeriod | WeeklyPeriod | MonthlyPeriod | YearlyPeriod | SpecificDatePeriod


class OcsNodeSchedule(TypedDict):
    """OCS schedule."""

    node_count: int
    period: Period
    drain_time: NotRequired[int]


class OcsScheduleDefinition(TypedDict):
    """OCS schedule definition."""

    default: NodeDefaultParams
    schedule: list[OcsNodeSchedule]


class OcsScheduleDescription(TypedDict):
    """OCS schedule description."""

    default_node_count: str
    down_type: str
    drain_time: str | None
    schedule: list[str]


class DatetimePeriod(TypedDict):
    """Datetime period."""

    begin: dt
    end: dt


SwarmNodeStatusKey: TypeAlias = Literal["active", "pause", "drain"]
OcsNodeStatusKey: TypeAlias = Literal["up", "drain", "power_down", "deleted"]
NodeStatus: TypeAlias = SwarmNodeStatus | OcsNodeStatus
SwarmScheduleDefinition: TypeAlias = list[SwarmNodeStatusSchedule]
NodeStatusSchedule: TypeAlias = SwarmScheduleDefinition | OcsScheduleDefinition
