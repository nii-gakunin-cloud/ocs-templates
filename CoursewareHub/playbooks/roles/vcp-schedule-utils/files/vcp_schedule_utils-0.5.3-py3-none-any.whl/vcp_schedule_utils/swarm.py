# SPDX-FileCopyrightText: 2025-present NII Gakunin Cloud <cld-office-support@nii.ac.jp>
#
# SPDX-License-Identifier: Apache-2.0
"""Utility functions for the Swarm Node status."""

from contextlib import suppress
from datetime import datetime as dt
from datetime import timedelta
from logging import getLogger
from os import environ
from typing import cast

from vcp_schedule_utils.schedule import convert_day_of_week, diff_schedule, schedule_to_description
from vcp_schedule_utils.types import (
    DailySchedule,
    MonthlySchedule,
    OcsScheduleDefinition,
    SwarmNodeStatus,
    SwarmNodeStatusKey,
    SwarmNodeStatusSchedule,
    SwarmScheduleDefinition,
    WeeklySchedule,
)

NODE_PARAMETERS: list[SwarmNodeStatusKey] = ["active", "pause", "drain"]
DEFAULT_SWARM_SCHEDULES = 3
logger = getLogger(__name__)


def _get_node_state_count(params: SwarmNodeStatus) -> SwarmNodeStatus:
    """Get the node state and the number of nodes."""
    return {
        "active": params["active"],
        "pause": params["pause"],
        "drain": params["drain"],
    }


def _get_node_state_ip_address(params: SwarmNodeStatus) -> dict[SwarmNodeStatusKey, list[str]]:
    """Get the node state and IP addresses."""
    ip_addresses = [addr.strip() for addr in environ["IP_ADDRESS"].split(",")]
    total = sum(params[state] for state in NODE_PARAMETERS)
    if total > len(ip_addresses):
        msg = "The number of IP addresses is insufficient."
        raise RuntimeError(msg)

    ret = {}
    for state in NODE_PARAMETERS:
        count = params[state]
        ret[state] = ip_addresses[:count]
        ip_addresses = ip_addresses[count:]
    return ret


def get_swarm_node_state(
    params: SwarmNodeStatus,
) -> dict[SwarmNodeStatusKey, list[str]] | SwarmNodeStatus:
    """Get the node state and the number of nodes or IP addresses."""
    return (
        _get_node_state_ip_address(params)
        if "IP_ADDRESS" in environ
        else _get_node_state_count(params)
    )


def _expand_monthly(schedule: MonthlySchedule, now: dt) -> list[dt]:
    hour = schedule["hour"]
    minute = schedule["minute"]
    day = schedule["day"]
    res = []
    with suppress(ValueError):
        res = [now.replace(day=day, hour=hour, minute=minute, second=0, microsecond=0)]

    try:
        if now.month > 1:
            res.append(
                now.replace(
                    month=now.month - 1,
                    day=day,
                    hour=hour,
                    minute=minute,
                    second=0,
                    microsecond=0,
                )
            )
        else:
            res.append(
                now.replace(
                    year=now.year - 1,
                    month=12,
                    day=day,
                    hour=hour,
                    minute=minute,
                    second=0,
                    microsecond=0,
                )
            )
    except ValueError:
        res.append(
            now.replace(
                month=now.month - 2,
                day=day,
                hour=hour,
                minute=minute,
                second=0,
                microsecond=0,
            )
        )
    return res


def _expand_weekly(schedule: WeeklySchedule, now: dt) -> list[dt]:
    hour = schedule["hour"]
    minute = schedule["minute"]
    diff = schedule["day_of_week"] - (now.isoweekday() % 7)
    zero = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
    if diff != 0:
        return [zero + timedelta(days=diff if diff < 0 else diff - 7)]
    return [zero - timedelta(days=7), zero]


def _expand_daily(schedule: DailySchedule, now: dt) -> list[dt]:
    hour = schedule["hour"]
    minute = schedule["minute"]
    target = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
    return [target - timedelta(days=1), target]


def _expand_schedule(ent: SwarmNodeStatusSchedule, now: dt) -> list[dt]:
    schedule = ent["schedule"]
    if "day" in schedule:
        return _expand_monthly(cast(MonthlySchedule, schedule), now)
    if "day_of_week" in schedule:
        return _expand_weekly(cast(WeeklySchedule, schedule), now)
    return _expand_daily(schedule, now)


def _expand_schedules(
    cfg: list[SwarmNodeStatusSchedule], now: dt
) -> dict[dt, SwarmNodeStatusSchedule]:
    res = {}
    for ent in cfg:
        ext = _expand_schedule(ent, now)
        res.update({x: ent for x in ext})
    return res


def get_swarm_node_status(cfg: list[SwarmNodeStatusSchedule], now: dt) -> SwarmNodeStatus:
    """Get the current schedule entry."""
    if len(cfg) == 1:
        return cfg[0]
    schedules = _expand_schedules(cfg, now)
    past = sorted([x for x in schedules if x <= now])
    return schedules[past[-1]]


def update_swarm_day_of_week(cfg) -> SwarmScheduleDefinition:
    """Update the day of the week in the Swarm schedule."""
    for item in cfg:
        if "day_of_week" in item["schedule"]:
            item["schedule"]["day_of_week"] = convert_day_of_week(item["schedule"]["day_of_week"])
    return cfg


def _check_convertible_to_ocs(cfg: SwarmScheduleDefinition) -> None:
    if len(cfg) != DEFAULT_SWARM_SCHEDULES:
        msg = "The schedule must have three entries."
        raise ValueError(msg)

    node_count = [schd["active"] + schd["pause"] + schd["drain"] for schd in cfg]
    if not all(node_count[0] == x for x in node_count[1:]):
        msg = "The number of nodes must be the same."
        raise ValueError(msg)
    power_on = [schd["active"] + schd["pause"] for schd in cfg]
    if power_on[0] != power_on[1]:
        msg = "The number of nodes to power on must be the same."
        raise ValueError(msg)
    if (diff := power_on[0] - power_on[2]) > 0 and cfg[1]["pause"] != diff:
        msg = "The number of nodes to pause must be the same as the number of nodes to power off."
        raise ValueError(msg)


def convert_ocs_schedule(
    swarm_cfg: SwarmScheduleDefinition, down_type: str
) -> OcsScheduleDefinition:
    """Convert the OCS schedule to the Swarm schedule."""
    _check_convertible_to_ocs(swarm_cfg)
    power_on = [schd["active"] + schd["pause"] for schd in swarm_cfg]
    assert len(power_on) == DEFAULT_SWARM_SCHEDULES  # noqa: S101
    max_node_count = power_on[0] + swarm_cfg[0]["drain"]
    return {
        "default": {
            "node_count": power_on[2],
            "max_node_count": max_node_count,
            "down_type": down_type,
            "drain_time": diff_schedule(swarm_cfg[1]["schedule"], swarm_cfg[2]["schedule"]),
        },
        "schedule": [
            {
                "node_count": power_on[0],
                "period": {
                    "begin": swarm_cfg[0]["schedule"],
                    "end": swarm_cfg[2]["schedule"],
                },
            }
        ],
    }


def swarm_to_description(cfg: SwarmScheduleDefinition) -> list[str]:
    """Convert the Swarm schedule definition to a description list."""
    desc = []
    for schedule in cfg:
        node_count = schedule["active"] + schedule["pause"]
        pause_count = schedule["pause"]
        schedule_txt = schedule_to_description(schedule["schedule"])
        if node_count > 0:
            text = f"{schedule_txt}からノード数を{node_count}にする。"
        else:
            text = f"{schedule_txt}から全てのノードを停止する。"
        if pause_count > 0:
            text += f"そのうち{pause_count}ノードは新規タスクを受け付けない。"
        desc.append(text)
    return desc
