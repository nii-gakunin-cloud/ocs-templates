# SPDX-FileCopyrightText: 2025-present NII Gakunin Cloud <cld-office-support@nii.ac.jp>
#
# SPDX-License-Identifier: Apache-2.0
"""Schedule utilities."""

from datetime import datetime as dt
from os import environ
from typing import cast
from zoneinfo import ZoneInfo

from dateutil.relativedelta import relativedelta

from vcp_schedule_utils.types import (
    DailySchedule,
    DatetimePeriod,
    MonthlySchedule,
    Period,
    Schedule,
    SpecificDateSchedule,
    WeeklySchedule,
    YearlySchedule,
)

TZ = "Asia/Tokyo" if "TZ" not in environ else environ["TZ"]
TZ_INFO = ZoneInfo(TZ)
DAY_OF_WEEK_LIST = [
    ["sun", "mon", "tue", "wed", "thu", "fri", "sat"],
    ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"],
    ["日", "月", "火", "水", "木", "金", "土"],
]


def convert_day_of_week(value: str | int) -> int:
    """Convert the day of the week to an integer."""
    if isinstance(value, int):
        return value
    if isinstance(value, str):
        txt = value.lower()
        for names in DAY_OF_WEEK_LIST:
            if txt in names:
                return names.index(txt)
    msg = f"The day of the week is incorrectly specified.: {value}"
    raise RuntimeError(msg)


def _daily_schedule_to_datetime(schedule: DailySchedule, now: dt) -> dt:
    hour = schedule["hour"]
    minute = schedule["minute"]
    return now + relativedelta(hour=hour, minute=minute, second=0, microsecond=0)


def _weekly_schedule_to_datetime(schedule: WeeklySchedule, now: dt) -> dt:
    hour = schedule["hour"]
    minute = schedule["minute"]
    weekday = wd if (wd := schedule["day_of_week"] - 1) >= 0 else 6
    return now + relativedelta(weekday=weekday, hour=hour, minute=minute, second=0, microsecond=0)


def _monthly_schedule_to_datetime(schedule: MonthlySchedule, now: dt) -> dt:
    hour = schedule["hour"]
    minute = schedule["minute"]
    day = schedule["day"]
    return now + relativedelta(day=day, hour=hour, minute=minute, second=0, microsecond=0)


def _yearly_schedule_to_datetime(schedule: YearlySchedule, now: dt) -> dt:
    hour = schedule["hour"]
    minute = schedule["minute"]
    day = schedule["day"]
    month = schedule["month"]
    return now + relativedelta(
        month=month, day=day, hour=hour, minute=minute, second=0, microsecond=0
    )


def _specific_date_to_datetime(schedule: SpecificDateSchedule) -> dt:
    hour = schedule["hour"]
    minute = schedule["minute"]
    day = schedule["day"]
    month = schedule["month"]
    year = schedule["year"]
    return dt(
        year=year,
        month=month,
        day=day,
        hour=hour,
        minute=minute,
        second=0,
        microsecond=0,
        tzinfo=TZ_INFO,
    )


def _schedule_to_datetime(schedule: Schedule, now: dt) -> dt:
    if "year" in schedule:
        return _specific_date_to_datetime(cast(SpecificDateSchedule, schedule))
    if "month" in schedule:
        return _yearly_schedule_to_datetime(cast(YearlySchedule, schedule), now)
    if "day" in schedule:
        return _monthly_schedule_to_datetime(cast(MonthlySchedule, schedule), now)
    if "day_of_week" in schedule:
        return _weekly_schedule_to_datetime(cast(WeeklySchedule, schedule), now)
    return _daily_schedule_to_datetime(cast(DailySchedule, schedule), now)


def _period_to_datetime_period(schedule: Period, now: dt) -> DatetimePeriod:
    delta = _period_to_delta(schedule["begin"])
    begin = _schedule_to_datetime(schedule["begin"], now)
    end = _schedule_to_datetime(schedule["end"], now)
    if begin > end:
        end += delta
    return {"begin": begin, "end": end}


def _expand_schedule(
    schedule: DatetimePeriod, delta: relativedelta
) -> tuple[DatetimePeriod, DatetimePeriod]:
    m = schedule.copy()
    p = schedule.copy()
    for key in m:
        m[key] -= delta  # type: ignore
        p[key] += delta  # type: ignore
    return (m, p)


def _check_included(periods: list[DatetimePeriod], now: dt) -> bool:
    return any(period["begin"] <= now < period["end"] for period in periods)


def _period_to_delta(schedule: Schedule) -> relativedelta:
    if "year" in schedule:
        return relativedelta()
    if "month" in schedule:
        return relativedelta(years=1)
    if "day" in schedule:
        return relativedelta(months=1)
    if "day_of_week" in schedule:
        return relativedelta(weeks=1)
    return relativedelta(days=1)


def check_included_period(schedule: Period, now: dt) -> bool:
    """Check if the current time is included in the period."""
    t0 = _period_to_datetime_period(schedule, now)
    delta = _period_to_delta(schedule["begin"])
    tm1, tp1 = _expand_schedule(t0, delta)
    return _check_included([tm1, t0, tp1], now)


def get_range_datetimes(schedules: list[Period], time_range: tuple[dt, dt]) -> list[dt]:
    """Get the times within the range."""

    tps = []
    for schedule in schedules:
        delta = _period_to_delta(schedule["begin"])
        t0 = _period_to_datetime_period(schedule, time_range[0])
        tm0, tp0 = _expand_schedule(t0, delta)
        t1 = _period_to_datetime_period(schedule, time_range[1])
        tm1, tp1 = _expand_schedule(t1, delta)
        tps.extend([tm0, t0, tp0, t1, tm1, tp1])

    result = []
    for tp in tps:
        if time_range[0] <= tp["begin"] < time_range[1]:
            result.append(tp["begin"])
        if time_range[0] < tp["end"] <= time_range[1]:
            result.append(tp["end"])
    return sorted(result)


def diff_schedule(begin: Schedule, end: Schedule) -> int:
    """Calculate the difference between the schedules."""
    nw = dt.now(tz=TZ_INFO)
    t0 = _schedule_to_datetime(begin, nw)
    t1 = _schedule_to_datetime(end, nw)
    if t0 > t1:
        t1 += _period_to_delta(begin)
    delta = t1 - t0
    return int(delta.total_seconds() / 60)


def _specific_date_to_text(schedule: SpecificDateSchedule) -> str:
    return f"{schedule['year']}年{_yearly_schedule_to_text(schedule)}"


def _yearly_schedule_to_text(schedule: YearlySchedule) -> str:
    return f"{schedule['month']}月{_monthly_schedule_to_text(schedule)}"


def _monthly_schedule_to_text(schedule: MonthlySchedule) -> str:
    return f"{schedule['day']}日{_daily_schedule_to_text(schedule)}"


def _weekly_schedule_to_text(schedule: WeeklySchedule) -> str:
    return f"{DAY_OF_WEEK_LIST[2][schedule['day_of_week']]}曜日{_daily_schedule_to_text(schedule)}"


def _daily_schedule_to_text(schedule: DailySchedule) -> str:
    return f"{schedule['hour']}:{schedule['minute']:02d}"


def schedule_to_description(schedule: Schedule) -> str:
    """Convert the schedule to a description."""
    if "year" in schedule:
        return _specific_date_to_text(cast(SpecificDateSchedule, schedule))
    if "month" in schedule:
        return _yearly_schedule_to_text(cast(YearlySchedule, schedule))
    if "day" in schedule:
        return _monthly_schedule_to_text(cast(MonthlySchedule, schedule))
    if "day_of_week" in schedule:
        return _weekly_schedule_to_text(cast(WeeklySchedule, schedule))

    return _daily_schedule_to_text(cast(DailySchedule, schedule))


def period_to_description(schedule: Period) -> str:
    """Convert the period to a description."""
    begin = schedule["begin"]
    end = schedule["end"]
    if "year" in begin:
        begin_txt = _specific_date_to_text(cast(SpecificDateSchedule, begin))
        end_txt = _specific_date_to_text(cast(SpecificDateSchedule, end))
        return f"{begin_txt}から{end_txt}まで"
    if "month" in begin:
        begin_txt = _yearly_schedule_to_text(cast(YearlySchedule, begin))
        end_txt = _yearly_schedule_to_text(cast(YearlySchedule, end))
        return f"毎年{begin_txt}から{end_txt}まで"
    if "day" in begin:
        begin_txt = _monthly_schedule_to_text(cast(MonthlySchedule, begin))
        end_txt = _monthly_schedule_to_text(cast(MonthlySchedule, end))
        return f"毎月{begin_txt}から{end_txt}まで"
    if "day_of_week" in begin:
        begin_txt = _weekly_schedule_to_text(cast(WeeklySchedule, begin))
        end_txt = _weekly_schedule_to_text(cast(WeeklySchedule, end))
        return f"毎週{begin_txt}から{end_txt}まで"

    begin_txt = _daily_schedule_to_text(cast(DailySchedule, begin))
    end_txt = _daily_schedule_to_text(cast(DailySchedule, end))
    return f"毎日{begin_txt}から{end_txt}まで"
