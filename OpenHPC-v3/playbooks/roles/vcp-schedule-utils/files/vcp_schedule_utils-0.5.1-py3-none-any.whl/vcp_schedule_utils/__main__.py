# SPDX-FileCopyrightText: 2025-present NII Gakunin Cloud <cld-office-support@nii.ac.jp>
#
# SPDX-License-Identifier: Apache-2.0
import sys

if __name__ == "__main__":
    from vcp_schedule_utils.cli import vcp_schedule_utils

    sys.exit(vcp_schedule_utils())
