# SPDX-FileCopyrightText: 2025-present NII Gakunin Cloud <cld-office-support@nii.ac.jp>
#
# SPDX-License-Identifier: Apache-2.0
"""Command line interface for vcp-schedule-utils."""

import json
from argparse import ArgumentParser, Namespace
from datetime import datetime
from logging import basicConfig, getLogger
from pathlib import Path
from typing import cast

import yaml

from vcp_schedule_utils import get_node_status, load_schedule, output_group_vars
from vcp_schedule_utils.__about__ import __version__
from vcp_schedule_utils.schedule import TZ_INFO
from vcp_schedule_utils.swarm import convert_ocs_schedule
from vcp_schedule_utils.types import NodeStatusSchedule, SwarmScheduleDefinition
from vcp_schedule_utils.utils import show_description

basicConfig(style="{")
logger = getLogger(__name__)


def _parse_args() -> Namespace:
    parser = ArgumentParser()
    parser.add_argument("-c", "--config", metavar="schedule.json", required=True)
    parser.add_argument("-o", "--output", metavar="group_vars/all/node.yml")
    parser.add_argument("-C", "--check", action="store_true")
    parser.add_argument("-t", "--type", choices=["swarm", "ocs"], default="ocs")
    parser.add_argument("-f", "--format", choices=["json", "json5", "toml", "yaml"])
    parser.add_argument("-D", "--description", action="store_true")
    parser.add_argument(
        "--desc-type",
        choices=["all", "default", "schedule", "node_count"],
        default="all",
    )
    parser.add_argument("--convert-ocs", metavar="schedule-ocs.json")
    parser.add_argument(
        "--convert-ocs-down-type",
        choices=["power_down", "deleted"],
        dest="down_type",
        default="power_down",
    )
    parser.add_argument("--force-default", action="store_true")
    parser.add_argument("--set-datetime", metavar="YYYY-MM-DDTHH:MM:SS")
    parser.add_argument("-v", "--version", action="version", version=f"%(prog)s {__version__}")
    return parser.parse_args()


def _convert_to_ocs(swarm_cfg: NodeStatusSchedule, params: Namespace) -> None:
    cfg = convert_ocs_schedule(cast(SwarmScheduleDefinition, swarm_cfg), params.down_type)
    cfg_path = Path(params.convert_ocs)
    if cfg_path.exists():
        logger.error("The file already exists: %s", cfg_path)
        raise FileExistsError
    match cfg_path.suffix.lower():
        case ".json" | ".json5" | "":
            with cfg_path.open("w", encoding="utf-8") as f:
                json.dump(cfg, f, indent=2)
        case ".yaml" | ".yml":
            with cfg_path.open("w", encoding="utf-8") as f:
                yaml.safe_dump(cfg, f)
        case _:
            msg = "Unsupported file extension: {params.convert_ocs.suffix}"
            logger.error(msg)
            raise ValueError(msg)


def vcp_schedule_utils() -> int:
    """Main function for vcp-schedule-utils."""
    try:
        params = _parse_args()
        if params.convert_ocs:
            params.type = "swarm"
        cfg = load_schedule(params.config, params.type, params.format)
        if params.check:
            return 0
        if params.description:
            show_description(cfg, params.desc_type, params.type)
            return 0
        if params.convert_ocs is not None:
            _convert_to_ocs(cfg, params)
            return 0

        if params.set_datetime:
            if (now := datetime.fromisoformat(params.set_datetime)).tzinfo is None:
                now = now.replace(tzinfo=TZ_INFO)
        else:
            now = datetime.now(tz=TZ_INFO)
        status = get_node_status(cfg, now, force_default=params.force_default)
        output_group_vars(params.output, status, params.type)
    except Exception:  # pylint: disable=broad-exception-caught
        logger.exception("An error occurred.")
        return 1
    return 0
