# SPDX-FileCopyrightText: 2025-present NII Gakunin Cloud <cld-office-support@nii.ac.jp>
#
# SPDX-License-Identifier: Apache-2.0
"""Utility functions for the VCP schedule."""

import json
import sys
from datetime import datetime as dt
from importlib.resources import files
from logging import getLogger
from pathlib import Path
from typing import Any, TextIO, cast

import json5
import yaml
from jsonschema import Draft202012Validator
from referencing import Registry, Resource

from vcp_schedule_utils.ocs import (
    get_ocs_node_state,
    get_ocs_node_status,
    ocs_schedule_validate,
    ocs_to_description,
    update_ocs_day_of_week,
)
from vcp_schedule_utils.swarm import (
    convert_ocs_schedule,
    get_swarm_node_state,
    get_swarm_node_status,
    update_swarm_day_of_week,
)
from vcp_schedule_utils.types import (
    NodeStatus,
    NodeStatusSchedule,
    OcsNodeStatus,
    OcsScheduleDefinition,
    OcsScheduleDescription,
    SwarmNodeStatus,
    SwarmScheduleDefinition,
)

logger = getLogger(__name__)


def get_node_status(cfg: NodeStatusSchedule, now: dt, *, force_default: bool = False) -> NodeStatus:
    """Get the node status for the current time."""
    if isinstance(cfg, list):
        return get_swarm_node_status(cfg, now)
    if isinstance(cfg, dict):
        return get_ocs_node_status(cfg, now, force_default=force_default)

    msg = "Invalid type."  # pragma: no cover
    raise RuntimeError(msg)  # pragma: no cover


def _get_validator(name: str) -> Draft202012Validator:
    """Get the JSON schema validator."""
    schema_dir = files("vcp_schedule_utils") / "schema"
    with (schema_dir / "schedule.json").open(encoding="utf-8") as f:
        common_schema = Resource.from_contents(json.load(f))
    registry: Registry = common_schema @ Registry()
    try:
        with (schema_dir / f"{name}.json").open(encoding="utf-8") as f:
            return Draft202012Validator(json.load(f), registry=registry)
    except FileNotFoundError as e:
        msg = f"Unsupported node type: {name}"
        raise ValueError(msg) from e


def _update_day_of_week(items) -> NodeStatusSchedule:
    if isinstance(items, list):
        return update_swarm_day_of_week(items)
    if isinstance(items, dict):
        return update_ocs_day_of_week(items)
    msg = "Invalid type."  # pragma: no cover
    raise RuntimeError(msg)  # pragma: no cover


def _load_json_schedule(file_name: str) -> Any:
    path_cfg = Path(file_name)
    with path_cfg.open(encoding="utf-8") as f:
        return json.load(f)


def _load_json5_schedule(file_name: str) -> Any:
    path_cfg = Path(file_name)
    with path_cfg.open(encoding="utf-8") as f:
        return json5.load(f)


def _load_yaml_schedule(file_name: str) -> Any:
    path_cfg = Path(file_name)
    with path_cfg.open(encoding="utf-8") as f:
        return yaml.safe_load(f)


if sys.version_info >= (3, 11):

    def _load_toml_schedule(file_name: str) -> Any:
        import tomllib

        path_cfg = Path(file_name)
        with path_cfg.open(mode="rb") as f:
            return tomllib.load(f)


def _load_schedule(file_name: str, fmt: str | None = None) -> Any:
    path_cfg = Path(file_name)
    if fmt is None:
        fmt = path_cfg.suffix[1:]
    match fmt:
        case "json":
            return _load_json_schedule(file_name)
        case "json5":
            return _load_json5_schedule(file_name)
        case "yaml" | "yml":
            return _load_yaml_schedule(file_name)
        case "toml" if sys.version_info >= (3, 11):
            return _load_toml_schedule(file_name)
        case _:
            msg = f"Unsupported format: {fmt}"
            raise ValueError(msg)


def load_schedule(file_name: str, node_type: str, fmt: str | None = None) -> NodeStatusSchedule:
    """Load the schedule from the specified file."""
    cfg = _load_schedule(file_name, fmt)
    validator = _get_validator(node_type)
    validator.validate(cfg)
    result: NodeStatusSchedule = _update_day_of_week(cfg)
    if node_type == "ocs":
        ocs_schedule_validate(cast(OcsScheduleDefinition, result))
    return result


def _output_group_vars(file_name: str, gvars: Any) -> None:
    path_output = Path(file_name)
    path_output.parent.mkdir(exist_ok=True, parents=True)
    with path_output.open(mode="w", encoding="utf-8") as f:
        yaml.safe_dump(gvars, f, default_flow_style=False)


def output_group_vars(file_name: str | None, params: NodeStatus, node_type: str) -> None:
    """Output the schedule file to an Ansible group variable file."""
    gvars: Any = None
    if node_type == "swarm":
        gvars = get_swarm_node_state(cast(SwarmNodeStatus, params))
    elif node_type == "ocs":
        gvars = get_ocs_node_state(cast(OcsNodeStatus, params))
    else:
        msg = f"Unknown node type: {node_type}"  # pragma: no cover
        raise RuntimeError(msg)  # pragma: no cover
    if file_name is None or file_name == "-":
        yaml.safe_dump(gvars, sys.stdout, default_flow_style=False)
    else:
        _output_group_vars(file_name, gvars)


def to_description(cfg: NodeStatusSchedule, node_type: str = "ocs") -> OcsScheduleDescription:
    """Convert the schedule definition to a description list."""
    if node_type == "ocs":
        return ocs_to_description(cast(OcsScheduleDefinition, cfg))
    if node_type == "swarm":
        ocs_cfg = convert_ocs_schedule(cast(SwarmScheduleDefinition, cfg), "deleted")
        if (
            "drain_time" not in ocs_cfg["default"] and "drain_time" in ocs_cfg["schedule"][0]
        ):  # pragma: no cover
            ocs_cfg["default"]["drain_time"] = ocs_cfg["schedule"][0]["drain_time"]
        return ocs_to_description(ocs_cfg)
    msg = f"Unknown node type: {node_type}"  # pragma: no cover
    raise RuntimeError(msg)  # pragma: no cover


def _show_schedule_description(desc: OcsScheduleDescription, *, file: TextIO) -> None:
    for item in desc["schedule"]:
        print(item, file=file)


def _show_general_description(desc: OcsScheduleDescription, *, file: TextIO) -> None:
    print(desc["down_type"], file=file)
    if desc["drain_time"]:
        print(desc["drain_time"], file=file)


def show_description(
    cfg: NodeStatusSchedule, desc_type: str, node_type: str = "ocs", *, file: TextIO = sys.stdout
) -> None:
    """Show the description of the schedule definition."""
    desc = to_description(cfg, node_type)
    match desc_type:
        case "all":
            print(desc["default_node_count"], file=file)
            _show_schedule_description(desc, file=file)
            print(file=file)
            _show_general_description(desc, file=file)
        case "default":
            print(desc["default_node_count"], file=file)
            _show_general_description(desc, file=file)
        case "schedule":
            _show_schedule_description(desc, file=file)
        case "node_count":
            print(desc["default_node_count"], file=file)
            _show_schedule_description(desc, file=file)
        case _:  # pragma: no cover
            msg = f"Unknown description type: {desc_type}"  # pragma: no cover
            raise ValueError(msg)  # pragma: no cover
