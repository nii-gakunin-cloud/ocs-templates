# SPDX-FileCopyrightText: 2025-present NII Gakunin Cloud <cld-office-support@nii.ac.jp>
#
# SPDX-License-Identifier: Apache-2.0
"""Utility functions for the OCS Node status."""

from datetime import datetime as dt
from datetime import timedelta
from functools import reduce
from logging import getLogger
from os import environ

from vcp_schedule_utils.schedule import (
    check_included_period,
    convert_day_of_week,
    get_range_datetimes,
    period_to_description,
)
from vcp_schedule_utils.types import (
    OcsNodeStatus,
    OcsNodeStatusKey,
    OcsScheduleDefinition,
    OcsScheduleDescription,
)

NODE_PARAMETERS: list[OcsNodeStatusKey] = ["up", "drain", "power_down", "deleted"]
logger = getLogger(__name__)


def _get_node_state_count(params: OcsNodeStatus) -> OcsNodeStatus:
    """Get the node state and the number of nodes."""
    ret: OcsNodeStatus = {
        "up": params["up"],
        "drain": params["drain"],
        "power_down": params["power_down"],
    }
    if "deleted" in params:
        ret["deleted"] = params["deleted"]
    return ret


def _get_node_state_ip_address(params: OcsNodeStatus) -> dict[OcsNodeStatusKey, list[str]]:
    """Get the node state and IP addresses."""
    ip_addresses = [addr.strip() for addr in environ["IP_ADDRESS"].split(",")]
    total = sum(params[state] for state in NODE_PARAMETERS if state != "deleted")
    if total > len(ip_addresses):
        msg = "The number of IP addresses is insufficient."
        raise RuntimeError(msg)

    ret: dict[OcsNodeStatusKey, list[str]] = {}
    for state in NODE_PARAMETERS:
        if state == "deleted":
            continue
        count = params[state]
        ret[state] = ip_addresses[:count]
        ip_addresses = ip_addresses[count:]
    ret["deleted"] = ip_addresses
    return ret


def get_ocs_node_state(
    params: OcsNodeStatus,
) -> dict[OcsNodeStatusKey, list[str]] | OcsNodeStatus:
    """Get the node state and the number of nodes or IP addresses."""
    return (
        _get_node_state_ip_address(params)
        if "IP_ADDRESS" in environ
        else _get_node_state_count(params)
    )


def _get_max_drain_minute(cfg: OcsScheduleDefinition) -> int:
    max_drain_minute = cfg["default"]["drain_time"] if "drain_time" in cfg["default"] else 0
    for schedule in cfg["schedule"]:
        if "drain_time" in schedule:
            max_drain_minute = max(max_drain_minute, schedule["drain_time"])
    return max_drain_minute


def _get_drain_minute(cfg: OcsScheduleDefinition, idx: int | None) -> int:
    if idx is not None and "drain_time" in (tgt := cfg["schedule"][idx]):
        return tgt["drain_time"]
    return cfg["default"]["drain_time"] if "drain_time" in cfg["default"] else 0


def _get_power_up(cfg: OcsScheduleDefinition, now: dt) -> tuple[int, int | None]:
    for idx, schedule in enumerate(cfg["schedule"]):
        if check_included_period(schedule["period"], now):
            return schedule["node_count"], idx
    return cfg["default"]["node_count"], None


def _get_drain(cfg: OcsScheduleDefinition, now: dt, power_up: int) -> int:
    max_time = _get_max_drain_minute(cfg)
    limit = now + timedelta(minutes=max_time)
    pts = get_range_datetimes([schd["period"] for schd in cfg["schedule"]], (now, limit))
    schedules = {pt: schd for pt in pts if (schd := _get_power_up(cfg, pt))[0] < power_up}
    drain = 0
    prev_count = power_up
    for pt, schedule in schedules.items():
        if prev_count == schedule[0]:
            continue
        drain_minute = _get_drain_minute(cfg, schedule[1])
        if pt - timedelta(minutes=drain_minute) <= now:
            drain = max(drain, power_up - schedule[0])
        prev_count = schedule[0]

    return drain


def _get_schedule_max_node_count(cfg: OcsScheduleDefinition) -> int:
    return reduce(
        lambda x, schedule: max(x, schedule["node_count"]),
        cfg["schedule"],
        cfg["default"]["node_count"],
    )


def _get_max_node_count(cfg: OcsScheduleDefinition) -> int:
    if "max_node_count" in cfg["default"]:
        return cfg["default"]["max_node_count"]
    return _get_schedule_max_node_count(cfg)


def _get_ocs_node_status(
    cfg: OcsScheduleDefinition, power_up: int, drain: int = 0
) -> OcsNodeStatus:
    max_node_count = _get_max_node_count(cfg)
    up = power_up - drain
    down = max_node_count - power_up
    match cfg["default"]["down_type"]:
        case "power_down":
            schedule_max = _get_schedule_max_node_count(cfg)
            if schedule_max == max_node_count:
                return {"up": up, "drain": drain, "power_down": down}
            return {
                "up": up,
                "drain": drain,
                "power_down": schedule_max - power_up,
                "deleted": max_node_count - schedule_max,
            }
        case "deleted":
            return {"up": up, "drain": drain, "power_down": 0, "deleted": down}
        case _:  # pragma: no cover
            msg = "Unknown down type"  # pragma: no cover
            raise ValueError(msg)  # pragma: no cover


def get_ocs_node_status(
    cfg: OcsScheduleDefinition, now: dt, *, force_default: bool = False
) -> OcsNodeStatus:
    """Get the OCS node status corresponding to the current time."""

    if force_default:
        power_up = cfg["default"]["node_count"]
        drain = 0
    else:
        power_up, _idx = _get_power_up(cfg, now)
        drain = _get_drain(cfg, now, power_up) if power_up > 0 else 0
    return _get_ocs_node_status(cfg, power_up, drain)


def update_ocs_day_of_week(items) -> OcsScheduleDefinition:
    """Update the day of the week in the OCS schedule."""
    for item in items["schedule"]:
        begin = item["period"]["begin"]
        end = item["period"]["end"]
        if "day_of_week" in begin:
            begin["day_of_week"] = convert_day_of_week(begin["day_of_week"])
        if "day_of_week" in end:
            end["day_of_week"] = convert_day_of_week(end["day_of_week"])
    return items


def ocs_schedule_validate(cfg: OcsScheduleDefinition) -> None:
    """Validate the OCS schedule."""
    max_node_count = _get_max_node_count(cfg)
    msg = "The node count is greater than the maximum node count."
    if max_node_count < cfg["default"]["node_count"]:
        raise ValueError(msg)
    for schedule in cfg["schedule"]:
        if max_node_count < schedule["node_count"]:
            raise ValueError(msg)


def _default_node_count_desc(cfg: OcsScheduleDefinition) -> str:
    count = cfg["default"]["node_count"]
    return f"通常時は{count}ノードを起動する" if count > 0 else "通常時は全てのノードを停止する"


def _down_type_desc(cfg: OcsScheduleDefinition) -> str:
    match cfg["default"]["down_type"]:
        case "power_down":
            return "ノード停止時は電源をオフにする"
        case "deleted":
            return "ノード停止時はノードを削除する"
        case _:  # pragma: no cover
            msg = "Unknown down type"  # pragma: no cover
            raise ValueError(msg)  # pragma: no cover


def _drain_time_desc(cfg: OcsScheduleDefinition) -> str | None:
    drain_time = cfg["default"]["drain_time"] if "drain_time" in cfg["default"] else 0
    return f"ノード停止の{drain_time}分前から新規タスクの受付を停止する" if drain_time > 0 else None


def ocs_to_description(cfg: OcsScheduleDefinition) -> OcsScheduleDescription:
    """Convert the OCS schedule definition to a description list."""
    schedules: list[str] = []
    for idx, schedule in enumerate(cfg["schedule"]):
        prefix = "上記期間以外の、" if idx > 0 else ""
        period = period_to_description(schedule["period"])
        if (count := schedule["node_count"]) > 0:
            schedules.append(f"{prefix}{period}はノード数を{count}にする")
        else:
            schedules.append(f"{prefix}{period}は全てのノードを停止する")
    return {
        "default_node_count": _default_node_count_desc(cfg),
        "down_type": _down_type_desc(cfg),
        "drain_time": _drain_time_desc(cfg),
        "schedule": schedules,
    }
